package api

import (
	"bytes"
	"encoding/json"
	"errors"
	"mime/multipart"
	"net/http"

	"github.com/google/uuid"
)

func MicrosoftDesigner(prompt string) (map[string]interface{}, error) {
	// Generate session ID
	sessionId, err := uuid.NewRandom()
	if err != nil {
		return nil, err
	}
	headers := map[string]string{
		"SessionId":         sessionId.String(),
		"X-UserSessionId":   sessionId.String(),
		"Platform":          "Android",
		"Caller":            "DesignerApp",
		"AudienceGroup":     "Production",
		"ClientName":        "DesignerApp",
		"HostApp":           "DesignerApp",
		"User-Agent":        "com.microsoft.designer/2023335701 (Linux; U; Android 13; in_ID; Redmi 9; Build/TQ2A.230505.002.A1; Cronet/114.0.5735.33)",
		"Accept-Encoding":   "gzip, deflate",
		"Transfer-Encoding": "chunked",
		"Authorization":     "eyJhbGciOiJSU0EtT0FFUCIsImVuYyI6IkExMjhDQkMtSFMyNTYiLCJ4NXQiOiJUWWRVektQcVBCVGRSN0NlTExvZ2hsVk9kRjgiLCJ6aXAiOiJERUYifQ.4aMG3sABvkop989ziOf_tzK3Kz2cwUgeptWK8MLo75nS7R-jbrxpf6yW1zgXupqIKbsZ3Y6Iqcdz053R7jBHZjhgzY5n2cLwlMiua4GjNg6TaiQpOWwY4UP867MVb6EWtpslf0nQN5Ig_p5rbw4PeROZTpsFSFCq1lQyVMfJGSX58B1BXup3kbxuEZ9PbZdd3uezLk999DYgI0-oCWl65gUmljF-RgmfxwB2QUIViR8zszkppZuMPZOv7isjqb7UleU5H-HYI4pZuyWPkJRw1BQB1qTfJEwip9uNWurcVJYnkj0ss7PBODJThOXirjJi8Ul2YpP_pVk_ebdsEs45TA.HsIF4HKL3vG02E8f6IN32A.NVphUVUp40h6xrx3BaRA7-0jDmMtx-OFUDweRi5cl2FjM7-hWpfvF5m0XG4ZPUBAHC5gkvxnnlVcLcNCgJ8-SauLJjpUeKzg_YbEmUVAtA3_NOMqqeqy_dqwN01sm4zb5jnHJWuPl-f_0Xq6S-lZnEaR_SP9kP9wfVo-7tUGlvzaNollDePHXx7qlb65csC22SaVuMAViE_3iSITB63IQ1e67GeztSgRKqYhg0ibszervVSSPJEeCfac7Jy5zwimQfJt7RBHtXThUhXQ6UQh_R7GAWBjwuNdzLtpKozJCgF9fgJ3kI7H2-DmvhDV3MsL5jDpGdPkRtZ1OFdUze5nFtkWEmBGCILfXT-LVYNpbgjeXTAP57i850cpDYeM2_C6oOqOTrcS9Edeqx4wbaGSK4O1me_hKtJrEe0q7b4-XSWYNPszmEabaJRi41HDW0945ktOMxafBbK75tW0S4leXrCi7WzFuQCHOibMe4Ju--Hz4ktwldcSUDmu5m_o-G-A2rWh1zCeVx-VVuwoCVgQFlSl1moI6I51Kuz-mV7Xky1ViV-mrj4DI4iIfKCaNhSVhz4OwL2lncXO1z8z0Vcsb4tRx8o5AhhW_nQ2Cjd6dHB6oAKqdXt2GM2TS_93KFuz1otCimUQwtBpDASjCuTMXLl1iGcwHJfIUyk9RQWmxVimWtsBHr8fLUG149V-QtgKst4e1I_y1-Am5KJJmlpYqAStmCpB0RBE5EmOUxz2touwcMlwJnFCjBdQlRcuyQcM0anb4z8cfeWp1zsY3irXS39f2Rxl4lqoFwbD21ClZEo0v5orKzyf6pC57Ygy2Irnzi-cQWRxat3P_mx9GBy8xw1-LTHCaGeQEmhEKo3boe6H7uxXgEFdOSpP3euWycGEdzsGJCKu-JvLBO8W1MgqH2XbL-WTAWQlF_8evgFRjEoL_GwIO_wsxIIc7avdjfl6ZxZdBnSv53i2Jdfj_7SCWBOpRZkjdR4_xkdP46zXvCrnjyj1CzZJIbLnDWO1HqyltGkA3M3Oth7LwitklrKMWzb7FMV7bFQq5wIMnUtbaJwVsuINCaPgI48MUE7W1jRQvGisbpjNGIQqD4aj0oCXMNRDxk83TTnry4hQ8lHGfjWCpBFmhhsH0bMgZUqDTHVFUaG3he0OGONWWtNB0jEnq2zH8v2OrlGpa9AJSYZ0ibOZmrLWvsRUrP95S0ToyHjnMcPofNewm_S6gt6qbIhePIHNLIH4N-CKNJjjI4-Dz0HKc7dyZ8AshKy1Lewlc5fPY6zyiHO10FimtBY-QROcoKoDnABpaBupAmqvQyRpe8OevkQjC7buAUTR0zGWwhoNsWLs03V2O2DzTOLgK3yKUwI4GbiQ8CiAuSlX8pL9uejpp3Wyvp8GfyZJwGYUouIzlHEmZriooC27543yQD3AwigpvNgG21RPp2QtZKlizZg.vqDLAeQjVdKdTxFf8SUtcA", //Get From https://designer.microsoft.com/
	}

	if headers["Authorization"] == "" {
		return nil, errors.New("Need Authorization")
	}

	// Create form data
	formData := bytes.NewBuffer(nil)
	writer := multipart.NewWriter(formData)

	writer.WriteField("dalle-caption", prompt)
	writer.WriteField("dalle-batch-size", "4")
	writer.WriteField("dalle-seed", "744")
	writer.WriteField("dalle-scenario-name", "TextToImage")
	writer.WriteField("dalle-image-response-format", "UrlWithBase64Thumbnail")
	writer.Close()

	// Create HTTP request
	req, err := http.NewRequest("POST", "https://designerapp.officeapps.live.com/designerapp/DallE.ashx?action=GetDallEImagesCogSci", formData)
	if err != nil {
		return nil, err
	}

	// Set headers
	req.Header.Set("Content-Type", writer.FormDataContentType())
	for key, value := range headers {
		req.Header.Set(key, value)
	}

	// Send request and handle response
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	// Parse response data
	var data map[string]interface{}
	err = json.NewDecoder(resp.Body).Decode(&data)
	if err != nil {
		return nil, err
	}

	return data, err
}
